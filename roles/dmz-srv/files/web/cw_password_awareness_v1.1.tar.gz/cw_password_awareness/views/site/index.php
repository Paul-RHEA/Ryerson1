<?php

/* @var $this yii\web\View */

$this->title = 'My Simple Web Application';
?>
<div class="site-index">

    <div class="jumbotron">
        <h1>Congratulations!</h1>

        <p class="lead">You have successfully logged in.</p>

    </div>

    <div class="body-content">

        <div class="row">
            <h2 style="text-align: center;">Are you sure you are a legitimate user???</h2>
        </div>

    </div>
</div>
